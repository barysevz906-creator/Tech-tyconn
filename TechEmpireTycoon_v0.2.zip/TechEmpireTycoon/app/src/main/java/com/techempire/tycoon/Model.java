package com.techempire.tycoon;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

final class Model {
    enum Type {
        SMARTPHONE("Смартфон"), TABLET("Планшет"), LAPTOP("Ноутбук"), WATCH("Часы"), HEADPHONES("Наушники"),
        OS("ОС"), PROCESSOR("Процессор"), ACCESSORY("Аксессуар"), CONSOLE("Консоль"), GAME("Игра");
        final String title; Type(String t){title=t;}
    }
    enum Stage { DRAFT, DEVELOPMENT, PRODUCTION, RELEASED }
    enum Tech { AMOLED, OLED, HIGH_REFRESH, FAST_CHARGE, WIRELESS_CHARGE, FOLDABLE, AI_CAMERA, OIS, FIVE_G, TITANIUM,
        UFS_STORAGE, WATERPROOF, RAY_TRACING, DLSS_LIKE, CUSTOM_SOC, LIQUID_COOLING, HAPTIC, VR, ONLINE_SERVICES,
        CROSSPLAY, ADVANCED_AI, GA_N_CHARGER, MAGNETIC_ACCESSORY, REINFORCED_CASE }

    static class Product {
        String name; Type type; Stage stage=Stage.DRAFT;
        int level=1, devPoints=0, quality=50, units=0;
        double cost=35, price=499;
        int design=50, display=50, camera=50, performance=50, battery=50, durability=50, software=50, value=50;
        int bodyColor=0; boolean curved=false, notch=false, active=false;
        EnumSet<Tech> techs=EnumSet.noneOf(Tech.class);
        double rating=5.0;
        Product(String n,Type t){name=n;type=t;}
        void recalc(){
            quality=(design+display+camera+performance+battery+durability+software+value)/8;
            rating=Math.max(1,Math.min(10,
                design*.13+display*.14+camera*.13+performance*.18+battery*.12+durability*.10+software*.12+value*.08)/10.0);
            cost=25 + quality*2.7 + techs.size()*17;
            if(type==Type.GAME) cost=10+quality*1.6+techs.size()*9;
            if(type==Type.ACCESSORY) cost=5+quality*0.75+techs.size()*5;
            if(price<cost*1.15) price=Math.ceil(cost*1.35);
        }
        double demand(){return Math.max(0.2,(rating/10.0)*(1+quality/180.0));}
        void develop(){
            stage=Stage.DEVELOPMENT; devPoints+=3+level*2;
            int q=2+level/2;
            design=Math.min(100,design+q); performance=Math.min(100,performance+q);
            recalc();
        }
        void improve(String stat){
            if(devPoints<10)return;
            devPoints-=10;
            if(stat.equals("design"))design=Math.min(100,design+6);
            if(stat.equals("display"))display=Math.min(100,display+6);
            if(stat.equals("camera"))camera=Math.min(100,camera+6);
            if(stat.equals("performance"))performance=Math.min(100,performance+6);
            if(stat.equals("battery"))battery=Math.min(100,battery+6);
            if(stat.equals("durability"))durability=Math.min(100,durability+6);
            if(stat.equals("software"))software=Math.min(100,software+6);
            recalc();
        }
        void addTech(Tech t){techs.add(t); recalc();}
        String techNames(){
            StringBuilder b=new StringBuilder(); for(Tech t:techs){if(b.length()>0)b.append(", ");b.append(t.name());} return b.toString();
        }
    }

    static class Subsidiary {
        String name; double cash; EnumSet<Type> specialties=EnumSet.noneOf(Type.class);
        ArrayList<Product> products=new ArrayList<>();
        Subsidiary(String n,double c){name=n;cash=c;}
    }

    static class Company {
        String name="NovaTech"; String country="Global"; double cash=1250000, fans=12500, valuation=1250000;
        int year=2028,month=3,day=15; int research=90, design=3,engineering=4,marketing=3,officeLevel=2,stores=3;
        ArrayList<Product> products=new ArrayList<>(); ArrayList<Subsidiary> subsidiaries=new ArrayList<>();
        EnumSet<Tech> unlocked=EnumSet.of(Tech.OLED,Tech.FAST_CHARGE,Tech.OIS,Tech.HAPTIC);
        Random rng=new Random();
        Company(){Product p=new Product("Nova X1",Type.SMARTPHONE);p.stage=Stage.RELEASED;p.active=true;p.price=749;p.techs.addAll(unlocked);p.recalc();products.add(p);}
        void tick(){
            double revenue=0,expense=700+officeLevel*180+stores*90;
            for(Product p:products) if(p.stage==Stage.RELEASED && p.active){
                double sold=Math.min(1800,15+p.demand()*fans/160.0*(1+marketing*.04)+rng.nextInt(20));
                revenue+=sold*p.price; p.units+=(int)sold; fans+=sold*(p.rating/10)*0.55;
                expense+=sold*p.cost;
            }
            cash+=revenue-expense; valuation=Math.max(0,cash+fans*14+products.size()*18000+subsidiaries.size()*90000);
            day++; if(day>30){day=1;month++;if(month>12){month=1;year++;}}
            research+=2+officeLevel;
        }
        int techCost(Tech t){return 20+t.ordinal()*7;}
        int researchCost(Type t){ switch(t){ case ACCESSORY:return 15; case CONSOLE:return 25; case GAME:return 20; case TABLET:case WATCH:case HEADPHONES:return 18; case LAPTOP:return 22; case OS:case PROCESSOR:return 30; default:return 10; } }
        boolean researchTech(Tech t){int c=techCost(t);if(unlocked.contains(t)||research<c)return false;research-=c;unlocked.add(t);return true;}
        JSONObject productJson(Product p)throws Exception{
            JSONObject q=new JSONObject();q.put("name",p.name);q.put("type",p.type.name());q.put("stage",p.stage.name());q.put("level",p.level);q.put("devPoints",p.devPoints);q.put("quality",p.quality);q.put("units",p.units);q.put("cost",p.cost);q.put("price",p.price);q.put("rating",p.rating);q.put("active",p.active);
            q.put("design",p.design);q.put("display",p.display);q.put("camera",p.camera);q.put("performance",p.performance);q.put("battery",p.battery);q.put("durability",p.durability);q.put("software",p.software);q.put("value",p.value);q.put("bodyColor",p.bodyColor);q.put("curved",p.curved);q.put("notch",p.notch);JSONArray a=new JSONArray();for(Tech t:p.techs)a.put(t.name());q.put("techs",a);return q;
        }
        JSONObject save()throws Exception{
            JSONObject o=new JSONObject();o.put("name",name);o.put("country",country);o.put("cash",cash);o.put("fans",fans);o.put("valuation",valuation);o.put("year",year);o.put("month",month);o.put("day",day);o.put("research",research);o.put("design",design);o.put("engineering",engineering);o.put("marketing",marketing);o.put("office",officeLevel);o.put("stores",stores);
            JSONArray u=new JSONArray();for(Tech t:unlocked)u.put(t.name());o.put("unlocked",u);JSONArray ps=new JSONArray();for(Product p:products)ps.put(productJson(p));o.put("products",ps);
            JSONArray ss=new JSONArray();for(Subsidiary s:subsidiaries){JSONObject z=new JSONObject();z.put("name",s.name);z.put("cash",s.cash);JSONArray sp=new JSONArray();for(Type t:s.specialties)sp.put(t.name());z.put("specialties",sp);ss.put(z);}o.put("subsidiaries",ss);return o;
        }
        static Company load(JSONObject o)throws Exception{
            Company c=new Company();c.name=o.optString("name","NovaTech");c.country=o.optString("country","Global");c.cash=o.optDouble("cash",1250000);c.fans=o.optDouble("fans",12500);c.valuation=o.optDouble("valuation",1250000);c.year=o.optInt("year",2028);c.month=o.optInt("month",3);c.day=o.optInt("day",15);c.research=o.optInt("research",90);c.design=o.optInt("design",3);c.engineering=o.optInt("engineering",4);c.marketing=o.optInt("marketing",3);c.officeLevel=o.optInt("office",2);c.stores=o.optInt("stores",3);
            c.unlocked.clear();JSONArray u=o.optJSONArray("unlocked");if(u!=null)for(int i=0;i<u.length();i++)c.unlocked.add(Tech.valueOf(u.getString(i)));
            c.products.clear();JSONArray ps=o.optJSONArray("products");if(ps!=null)for(int i=0;i<ps.length();i++){JSONObject q=ps.getJSONObject(i);Product p=new Product(q.optString("name","Product"),Type.valueOf(q.optString("type","SMARTPHONE")));p.stage=Stage.valueOf(q.optString("stage","DRAFT"));p.level=q.optInt("level",1);p.devPoints=q.optInt("devPoints",0);p.quality=q.optInt("quality",50);p.units=q.optInt("units",0);p.cost=q.optDouble("cost",35);p.price=q.optDouble("price",499);p.rating=q.optDouble("rating",5);p.active=q.optBoolean("active",false);p.design=q.optInt("design",50);p.display=q.optInt("display",50);p.camera=q.optInt("camera",50);p.performance=q.optInt("performance",50);p.battery=q.optInt("battery",50);p.durability=q.optInt("durability",50);p.software=q.optInt("software",50);p.value=q.optInt("value",50);p.bodyColor=q.optInt("bodyColor",0);p.curved=q.optBoolean("curved",false);p.notch=q.optBoolean("notch",false);JSONArray a=q.optJSONArray("techs");if(a!=null)for(int j=0;j<a.length();j++)p.techs.add(Tech.valueOf(a.getString(j)));c.products.add(p);}
            c.subsidiaries.clear();JSONArray ss=o.optJSONArray("subsidiaries");if(ss!=null)for(int i=0;i<ss.length();i++){JSONObject z=ss.getJSONObject(i);Subsidiary s=new Subsidiary(z.optString("name","Subsidiary"),z.optDouble("cash",0));JSONArray sp=z.optJSONArray("specialties");if(sp!=null)for(int j=0;j<sp.length();j++)s.specialties.add(Type.valueOf(sp.getString(j)));c.subsidiaries.add(s);}return c;
        }
    }
}
