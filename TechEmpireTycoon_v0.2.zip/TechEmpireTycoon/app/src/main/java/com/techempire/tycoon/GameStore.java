package com.techempire.tycoon;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;

final class GameStore {
    private final SharedPreferences p;
    GameStore(Context c){p=c.getSharedPreferences("save",Context.MODE_PRIVATE);}
    Model.Company load(){
        try{
            String s=p.getString("company",null);
            return s==null?new Model.Company():Model.Company.load(new JSONObject(s));
        }catch(Exception e){return new Model.Company();}
    }
    void save(Model.Company c){
        try{p.edit().putString("company",c.save().toString()).apply();}catch(Exception ignored){}
    }
}
