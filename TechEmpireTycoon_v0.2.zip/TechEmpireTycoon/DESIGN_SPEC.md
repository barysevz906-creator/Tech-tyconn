# Design specification

## Product progression

### Accessories
Level 1: basic plastic charger/case.
Level 2: fast charging / reinforced case.
Level 3: GaN / magnetic ecosystem.
Level 4: intelligent accessory with diagnostics.
Level 5: premium ecosystem accessory.

### Consoles
Branches: CPU -> GPU -> cooling -> memory -> storage -> controller -> online services -> VR.
Each branch raises quality but can raise BOM cost and launch price.

### Games
Branches: engine -> graphics -> physics -> AI -> content -> multiplayer -> optimization.
Quality is calculated from the weighted branch levels and drives reviews and sales.

## Subsidiaries

A subsidiary is an independent cash pool with multiple specialties.
Transfers are explicit transactions:
- parent -> subsidiary: investment;
- subsidiary -> parent: dividend/return of capital.

Recommended next implementation:
- intercompany loans;
- tax;
- transfer pricing;
- subsidiary CEOs;
- independent P&L;
- brand architecture;
- shared services;
- mergers and acquisitions.

## Suggested future systems

- full 3D product editor;
- component catalogue with thousands of combinations;
- suppliers and manufacturing plants;
- patents;
- licensing;
- competing AI companies;
- loans, shares and dividends;
- presentations and reviews;
- global stores;
- marketing channels;
- market events;
- achievements and leaderboards.
