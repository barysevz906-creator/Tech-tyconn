# Tech Empire Tycoon v0.3

Standalone Android tech-company tycoon prototype.

### Included
- redesigned dark futuristic UI;
- company dashboard and metrics;
- product catalogue;
- visual device preview for multiple categories;
- interactive device editor with tabs;
- design/color/form controls;
- development -> production -> release lifecycle;
- Dev Points earned through development;
- component upgrades using Dev Points;
- 1-10 product rating from eight characteristics;
- rating-dependent sales and fan growth;
- Research Points and technology tree;
- smartphones, tablets, laptops, watches, headphones, OS, processors;
- accessories, game consoles and games;
- holding and multi-specialty subsidiaries;
- money transfers between parent and subsidiaries;
- local JSON save.

### Build
Open the project in Android Studio and run `Build -> Generate APK(s)`.
The debug APK will be created under `app/build/outputs/apk/debug/`.

No Devices Tycoon artwork, logo or proprietary assets are included.
