package com.techempire.tycoon;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

final class Model {
    enum Type {
        SMARTPHONE("Смартфон"), TABLET("Планшет"), LAPTOP("Ноутбук"),
        WATCH("Часы"), HEADPHONES("Наушники"), OS("ОС"), PROCESSOR("Процессор"),
        ACCESSORY("Аксессуар"), CONSOLE("Игровая консоль"), GAME("Игра");
        final String title; Type(String t){title=t;}
    }

    static class Product {
        String name;
        Type type;
        int level, quality, units;
        double cost, price;
        boolean active;
        Product(String n, Type t) {
            name=n; type=t; level=1; quality=50; units=0; cost=20; price=49; active=false;
        }
        double margin(){ return Math.max(0, price-cost); }
    }

    static class Subsidiary {
        String name;
        double cash;
        EnumSet<Type> specialties = EnumSet.noneOf(Type.class);
        ArrayList<Product> products = new ArrayList<>();
        Subsidiary(String n, double c){name=n; cash=c;}
    }

    static class Company {
        String name = "Nova Technologies";
        String country = "Global";
        double cash = 250000;
        double fans = 1200;
        double valuation = 250000;
        int year = 2026, month = 1, day = 1;
        int research = 0, design = 0, engineering = 0, marketing = 0;
        int officeLevel = 1, stores = 1;
        ArrayList<Product> products = new ArrayList<>();
        ArrayList<Subsidiary> subsidiaries = new ArrayList<>();
        Random rng = new Random();

        Company(){
            products.add(new Product("Nova One", Type.SMARTPHONE));
        }

        void tick() {
            double revenue=0, expense=120 + officeLevel*55 + stores*35;
            for(Product p: products) if(p.active){
                double demand = (p.quality/50.0) * (1 + fans/50000.0) * (1 + marketing/100.0);
                double sold = Math.max(1, Math.min(140, demand*4 + rng.nextInt(8)));
                revenue += sold*p.price;
                p.units += (int)sold;
                fans += sold*0.6;
                expense += sold*p.cost;
            }
            for(Subsidiary s: subsidiaries) {
                for(Product p: s.products) if(p.active){
                    double sold=Math.max(0, Math.min(70, p.quality*0.65 + marketing*0.2));
                    s.cash += sold*(p.price-p.cost);
                }
            }
            cash += revenue-expense;
            valuation = Math.max(0, cash + fans*8 + products.size()*5000 + subsidiaries.size()*25000);
            day++;
            if(day>30){day=1;month++; if(month>12){month=1;year++;}}
            if(research<999999) research += 1;
        }

        void research(Type t){
            int cost = 15 + researchCost(t);
            if(research>=cost){ research-=cost; unlock(t); }
        }
        int researchCost(Type t){
            switch(t){
                case ACCESSORY:return 15;
                case CONSOLE:return 25;
                case GAME:return 20;
                case TABLET: case WATCH: case HEADPHONES:return 18;
                case LAPTOP:return 22;
                case OS: case PROCESSOR:return 30;
                default:return 10;
            }
        }
        void unlock(Type t){
            if(t==Type.ACCESSORY && marketing<30) marketing+=3;
            if(t==Type.CONSOLE && engineering<40) engineering+=4;
            if(t==Type.GAME && design<40) design+=4;
        }

        JSONObject save() throws Exception{
            JSONObject o=new JSONObject();
            o.put("name",name); o.put("country",country); o.put("cash",cash); o.put("fans",fans);
            o.put("valuation",valuation); o.put("year",year); o.put("month",month); o.put("day",day);
            o.put("research",research); o.put("design",design); o.put("engineering",engineering);
            o.put("marketing",marketing); o.put("office",officeLevel); o.put("stores",stores);
            JSONArray ps=new JSONArray();
            for(Product p:products) ps.put(productJson(p));
            o.put("products",ps);
            JSONArray ss=new JSONArray();
            for(Subsidiary s:subsidiaries){
                JSONObject q=new JSONObject(); q.put("name",s.name); q.put("cash",s.cash);
                JSONArray sp=new JSONArray(); for(Type t:s.specialties) sp.put(t.name());
                q.put("specialties",sp); ss.put(q);
            }
            o.put("subsidiaries",ss);
            return o;
        }

        static JSONObject productJson(Product p) throws Exception{
            JSONObject q=new JSONObject(); q.put("name",p.name); q.put("type",p.type.name());
            q.put("level",p.level); q.put("quality",p.quality); q.put("units",p.units);
            q.put("cost",p.cost); q.put("price",p.price); q.put("active",p.active); return q;
        }

        static Company load(JSONObject o) throws Exception{
            Company c=new Company();
            c.name=o.optString("name","Nova Technologies"); c.country=o.optString("country","Global");
            c.cash=o.optDouble("cash",250000); c.fans=o.optDouble("fans",1200); c.valuation=o.optDouble("valuation",250000);
            c.year=o.optInt("year",2026); c.month=o.optInt("month",1); c.day=o.optInt("day",1);
            c.research=o.optInt("research",0); c.design=o.optInt("design",0); c.engineering=o.optInt("engineering",0);
            c.marketing=o.optInt("marketing",0); c.officeLevel=o.optInt("office",1); c.stores=o.optInt("stores",1);
            c.products.clear();
            JSONArray ps=o.optJSONArray("products");
            if(ps!=null) for(int i=0;i<ps.length();i++){
                JSONObject q=ps.getJSONObject(i); Product p=new Product(q.optString("name","Product"),Type.valueOf(q.optString("type","SMARTPHONE")));
                p.level=q.optInt("level",1); p.quality=q.optInt("quality",50); p.units=q.optInt("units",0);
                p.cost=q.optDouble("cost",20); p.price=q.optDouble("price",49); p.active=q.optBoolean("active",false); c.products.add(p);
            }
            c.subsidiaries.clear();
            JSONArray ss=o.optJSONArray("subsidiaries");
            if(ss!=null) for(int i=0;i<ss.length();i++){
                JSONObject q=ss.getJSONObject(i); Subsidiary s=new Subsidiary(q.optString("name","Subsidiary"),q.optDouble("cash",0));
                JSONArray sp=q.optJSONArray("specialties"); if(sp!=null) for(int j=0;j<sp.length();j++) s.specialties.add(Type.valueOf(sp.getString(j)));
                c.subsidiaries.add(s);
            }
            return c;
        }
    }
}
