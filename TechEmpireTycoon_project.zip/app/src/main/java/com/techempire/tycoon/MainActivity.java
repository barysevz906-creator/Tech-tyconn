package com.techempire.tycoon;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    GameStore store;
    Model.Company company;
    GameView view;
    final Handler handler=new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(15,19,25));
        store=new GameStore(this); company=store.load();
        view=new GameView(this); setContentView(view);
        handler.post(ticker);
    }
    final Runnable ticker=new Runnable(){public void run(){
        company.tick(); store.save(company); view.invalidate(); handler.postDelayed(this,1200);
    }};
    @Override protected void onPause(){super.onPause();store.save(company);}
    @Override protected void onDestroy(){handler.removeCallbacks(ticker);super.onDestroy();}

    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    void createProduct(){
        final LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(30,10,30,10);
        EditText name=new EditText(this); name.setHint("Название продукта"); box.addView(name);
        Spinner spinner=new Spinner(this);
        String[] labels=new String[Model.Type.values().length];
        for(int i=0;i<labels.length;i++)labels[i]=Model.Type.values()[i].title;
        spinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,labels)); box.addView(spinner);
        EditText price=new EditText(this); price.setHint("Цена"); price.setInputType(2|8192); box.addView(price);
        EditText quality=new EditText(this); quality.setHint("Качество 1-100"); quality.setInputType(2); box.addView(quality);
        new AlertDialog.Builder(this).setTitle("Новый продукт").setView(box)
            .setPositiveButton("Создать",(d,w)->{
                String n=name.getText().toString().trim(); if(n.isEmpty())n="Product "+(company.products.size()+1);
                Model.Type t=Model.Type.values()[spinner.getSelectedItemPosition()];
                Model.Product p=new Model.Product(n,t);
                try{p.price=Double.parseDouble(price.getText().toString());}catch(Exception e){p.price=49;}
                try{p.quality=Math.max(1,Math.min(100,Integer.parseInt(quality.getText().toString())));}catch(Exception e){p.quality=50;}
                p.cost=Math.max(5,p.price*(1-p.quality/250.0)); company.products.add(p);
                toast("Продукт создан: "+n); view.invalidate();
            }).setNegativeButton("Отмена",null).show();
    }

    void createSubsidiary(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(30,10,30,10);
        EditText name=new EditText(this); name.setHint("Название дочерней компании"); box.addView(name);
        EditText money=new EditText(this); money.setHint("Стартовый капитал"); money.setInputType(2|8192); box.addView(money);
        boolean[] checked=new boolean[Model.Type.values().length];
        String[] labels=new String[checked.length]; for(int i=0;i<labels.length;i++)labels[i]=Model.Type.values()[i].title;
        new AlertDialog.Builder(this).setTitle("Создать дочернюю компанию")
            .setMultiChoiceItems(labels,checked,(d,which,isChecked)->checked[which]=isChecked)
            .setView(box).setPositiveButton("Создать",(d,w)->{
                double amount=50000; try{amount=Double.parseDouble(money.getText().toString());}catch(Exception e){}
                if(amount>company.cash){toast("Недостаточно средств");return;}
                if(name.getText().toString().trim().isEmpty()){toast("Введите название");return;}
                Model.Subsidiary s=new Model.Subsidiary(name.getText().toString().trim(),amount);
                for(int i=0;i<checked.length;i++)if(checked[i])s.specialties.add(Model.Type.values()[i]);
                if(s.specialties.isEmpty()){toast("Выберите хотя бы одно направление");return;}
                company.cash-=amount; company.subsidiaries.add(s); store.save(company); view.invalidate();
            }).setNegativeButton("Отмена",null).show();
    }

    void transfer(boolean toSub){
        if(company.subsidiaries.isEmpty()){toast("Сначала создайте дочернюю компанию");return;}
        String[] names=new String[company.subsidiaries.size()];
        for(int i=0;i<names.length;i++)names[i]=company.subsidiaries.get(i).name+" — "+money(company.subsidiaries.get(i).cash);
        new AlertDialog.Builder(this).setTitle(toSub?"Перевод из холдинга":"Возврат в холдинг")
            .setItems(names,(d,which)->{
                final Model.Subsidiary s=company.subsidiaries.get(which);
                EditText e=new EditText(this); e.setInputType(2|8192); e.setHint("Сумма");
                new AlertDialog.Builder(this).setTitle("Сумма: "+s.name).setView(e).setPositiveButton("Перевести",(dd,ww)->{
                    double x=0;try{x=Double.parseDouble(e.getText().toString());}catch(Exception ex){}
                    if(toSub){if(x>company.cash){toast("Недостаточно средств");return;}company.cash-=x;s.cash+=x;}
                    else{if(x>s.cash){toast("У дочерней компании недостаточно средств");return;}s.cash-=x;company.cash+=x;}
                    store.save(company);view.invalidate();
                }).setNegativeButton("Отмена",null).show();
            }).show();
    }

    void researchDialog(){
        String[] a=new String[Model.Type.values().length]; for(int i=0;i<a.length;i++){
            Model.Type t=Model.Type.values()[i]; a[i]=t.title+"  •  "+company.researchCost(t)+" RP";
        }
        new AlertDialog.Builder(this).setTitle("Исследования")
            .setItems(a,(d,w)->{Model.Type t=Model.Type.values()[w];int c=company.researchCost(t);
                if(company.research>=c){company.research-=c;toast("Исследование завершено: "+t.title);view.invalidate();}
                else toast("Нужно ещё "+(c-company.research)+" RP");
            }).show();
    }

    String money(double x){return String.format(Locale.US,"$%,.0f",x);}
}
