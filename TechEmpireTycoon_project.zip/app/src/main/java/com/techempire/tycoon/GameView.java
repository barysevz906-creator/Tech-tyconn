package com.techempire.tycoon;

import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import java.util.*;

public class GameView extends View {
    MainActivity a;
    Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    int screen=0;
    float scale=1;
    final String[] tabs={"Главная","Продукты","Холдинг","R&D","Рынок"};

    GameView(MainActivity c){super(c);a=c;p.setTypeface(Typeface.create("sans",Typeface.NORMAL));setBackgroundColor(Color.rgb(11,14,19));}
    void rect(Canvas c,float l,float t,float r,float b,int color){p.setColor(color);c.drawRoundRect(l,t,r,b,14,14,p);}
    void txt(Canvas c,String s,float x,float y,float size,int color){p.setTextSize(size);p.setColor(color);p.setTypeface(Typeface.create("sans",Typeface.NORMAL));c.drawText(s,x,y,p);}
    void bold(Canvas c,String s,float x,float y,float size,int color){p.setTextSize(size);p.setColor(color);p.setTypeface(Typeface.create("sans",Typeface.BOLD));c.drawText(s,x,y,p);}
    String m(double x){return String.format(Locale.US,"$%,.0f",x);}
    @Override protected void onDraw(Canvas c){
        super.onDraw(c); scale=getWidth()/1000f;
        c.save();c.scale(scale,scale);
        float W=1000,H=getHeight()/scale;
        rect(c,0,0,W,78,Color.rgb(18,23,31));
        bold(c,a.company.name,28,32,22,Color.WHITE);
        txt(c,"Tech Empire Tycoon",28,57,14,Color.rgb(130,145,165));
        txt(c,m(a.company.cash),700,30,20,Color.rgb(100,235,170));
        txt(c,"Fans "+String.format(Locale.US,"%,.0f",a.company.fans),700,55,14,Color.LTGRAY);

        float tabW=W/tabs.length;
        for(int i=0;i<tabs.length;i++){if(i==screen)rect(c,i*tabW,78,(i+1)*tabW,124,Color.rgb(35,75,90));txt(c,tabs[i],i*tabW+25,107,15,Color.WHITE);}
        if(screen==0)home(c); else if(screen==1)products(c); else if(screen==2)holding(c); else if(screen==3)rnd(c); else market(c);
        c.restore();
    }

    void card(Canvas c,float x,float y,float w,float h,String title,String value,String sub){
        rect(c,x,y,x+w,y+h,Color.rgb(22,28,37));bold(c,title,x+18,y+30,14,Color.rgb(160,175,195));
        bold(c,value,x+18,y+65,25,Color.WHITE);txt(c,sub,x+18,y+h-18,13,Color.rgb(115,130,150));
    }

    void home(Canvas c){
        card(c,22,145,225,125,"Деньги",m(a.company.cash),"свободный капитал");
        card(c,260,145,225,125,"Оценка",m(a.company.valuation),"стоимость бизнеса");
        card(c,498,145,225,125,"Фанаты",String.format(Locale.US,"%,.0f",a.company.fans),"аудитория бренда");
        card(c,736,145,242,125,"Дата",a.company.day+"."+a.company.month+"."+a.company.year,"игровое время");
        rect(c,22,292,635,520,Color.rgb(22,28,37));
        bold(c,"Быстрые действия",42,325,20,Color.WHITE);
        button(c,42,350,300,55,"Создать продукт",0);
        button(c,365,350,245,55,"Создать дочку",1);
        button(c,42,420,300,55,"Перевести деньги",2);
        button(c,365,420,245,55,"Исследования",3);
        rect(c,680,292,978,520,Color.rgb(22,28,37));
        bold(c,"Состояние империи",700,325,20,Color.WHITE);
        txt(c,"Продукты: "+a.company.products.size(),700,360,16,Color.LTGRAY);
        txt(c,"Дочерние компании: "+a.company.subsidiaries.size(),700,390,16,Color.LTGRAY);
        txt(c,"Магазины: "+a.company.stores,700,420,16,Color.LTGRAY);
        txt(c,"Офис: уровень "+a.company.officeLevel,700,450,16,Color.LTGRAY);
        txt(c,"R&D: "+a.company.research+" RP",700,480,16,Color.LTGRAY);
    }

    void button(Canvas c,float x,float y,float w,float h,String s,int action){
        rect(c,x,y,x+w,y+h,Color.rgb(35,46,58));bold(c,s,x+18,y+34,16,Color.WHITE);
    }

    void products(Canvas c){
        bold(c,"Продукты и линейки",24,158,24,Color.WHITE);
        txt(c,"Общий редактор: старые категории + аксессуары + консоли + игры",24,184,14,Color.rgb(135,150,170));
        button(c,720,145,250,50,"+ Новый продукт",10);
        float y=215;
        for(Model.Product p:a.company.products){
            rect(c,24,y,976,y+78,Color.rgb(22,28,37));
            bold(c,p.name,44,y+28,18,Color.WHITE);
            txt(c,p.type.title+" • L"+p.level+" • качество "+p.quality,44,y+53,13,Color.LTGRAY);
            txt(c,m(p.price),650,y+30,17,Color.rgb(100,235,170));
            txt(c,p.active?"В ПРОДАЖЕ":"Черновик",790,y+30,13,p.active?Color.rgb(100,235,170):Color.LTGRAY);
            if(p.active) txt(c,"Продано: "+p.units,790,y+54,12,Color.LTGRAY);
            y+=92;if(y>getHeight()/scale-20)break;
        }
    }

    void holding(Canvas c){
        bold(c,"Холдинг",24,158,24,Color.WHITE);
        txt(c,"Дочерние компании работают как самостоятельные бизнес-единицы.",24,184,14,Color.rgb(135,150,170));
        button(c,540,145,200,50,"+ Дочерняя",11);
        button(c,750,145,220,50,"Перевод средств",12);
        float y=215;
        if(a.company.subsidiaries.isEmpty()){
            txt(c,"Пока нет дочерних компаний.",45,y+30,17,Color.LTGRAY);
            txt(c,"Создай первую и выбери несколько направлений деятельности.",45,y+58,14,Color.rgb(135,150,170));
        }
        for(Model.Subsidiary s:a.company.subsidiaries){
            rect(c,24,y,976,y+115,Color.rgb(22,28,37));
            bold(c,s.name,44,y+30,19,Color.WHITE);
            txt(c,"Баланс: "+m(s.cash),44,y+57,14,Color.rgb(100,235,170));
            StringBuilder sb=new StringBuilder("Направления: ");
            for(Model.Type t:s.specialties){if(sb.length()>14)sb.append(", ");sb.append(t.title);}
            txt(c,sb.toString(),44,y+84,12,Color.LTGRAY);
            y+=130;
        }
    }

    void rnd(Canvas c){
        bold(c,"R&D / Исследования",24,158,24,Color.WHITE);
        txt(c,"Очки исследований накапливаются каждый игровой день.",24,184,14,Color.rgb(135,150,170));
        card(c,24,210,260,115,"Research Points",String.valueOf(a.company.research),"доступно");
        card(c,302,210,205,115,"Design",String.valueOf(a.company.design),"уровень команды");
        card(c,525,210,205,115,"Engineering",String.valueOf(a.company.engineering),"уровень команды");
        card(c,748,210,228,115,"Marketing",String.valueOf(a.company.marketing),"уровень команды");
        button(c,24,350,300,55,"Открыть исследование",13);
        bold(c,"Новые ветки",24,440,19,Color.WHITE);
        txt(c,"Аксессуары  •  Консоли  •  Игры",24,470,16,Color.LTGRAY);
        txt(c,"Каждая ветка повышает доступные рецепты, качество и спрос.",24,498,14,Color.rgb(135,150,170));
    }

    void market(Canvas c){
        bold(c,"Рынок и развитие",24,158,24,Color.WHITE);
        card(c,24,205,290,120,"Продажи","Реальное время","спрос зависит от качества");
        card(c,330,205,290,120,"Магазины",String.valueOf(a.company.stores),"глобальное покрытие");
        card(c,636,205,340,120,"Офис","Lv."+a.company.officeLevel,"люди и R&D");
        bold(c,"События рынка",24,370,20,Color.WHITE);
        txt(c,"• Тренд на игровые устройства",45,410,16,Color.LTGRAY);
        txt(c,"• Дефицит компонентов влияет на себестоимость",45,442,16,Color.LTGRAY);
        txt(c,"• Лояльность аудитории зависит от темпа релизов",45,474,16,Color.LTGRAY);
    }

    @Override public boolean onTouchEvent(android.view.MotionEvent e){
        if(e.getAction()!=MotionEvent.ACTION_UP)return true;
        float x=e.getX()/scale,y=e.getY()/scale;
        if(y>=78&&y<=124){screen=Math.min(4,(int)(x/(1000f/tabs.length)));invalidate();return true;}
        if(screen==0){
            if(y>340&&y<420&&x<350)a.createProduct();
            else if(y>340&&y<420&&x>350)a.createSubsidiary();
            else if(y>415&&y<490&&x<350)a.transfer(true);
            else if(y>415&&y<490)a.researchDialog();
        } else if(screen==1 && y>135&&y<205)a.createProduct();
        else if(screen==2){
            if(y>135&&y<205&&x>500&&x<750)a.createSubsidiary();
            else if(y>135&&y<205&&x>740)a.transfer(true);
        } else if(screen==3&&y>340&&y<420)a.researchDialog();
        return true;
    }
}
