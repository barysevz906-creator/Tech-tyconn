package com.techempire.tycoon;

import android.graphics.*;
import android.view.*;
import java.util.*;

public class GameView extends View {
    MainActivity a; Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); float sc; int screen=0; int selected=0; int editorTab=0;
    final int BG=Color.rgb(5,12,20), NAV=Color.rgb(7,18,29), PANEL=Color.rgb(10,25,39), PANEL2=Color.rgb(14,34,51), LINE=Color.rgb(28,61,82), CYAN=Color.rgb(33,211,244), TEXT=Color.WHITE, MUTED=Color.rgb(135,160,181), GREEN=Color.rgb(65,235,158), GOLD=Color.rgb(255,211,74), RED=Color.rgb(244,93,111), PURPLE=Color.rgb(157,104,255);
    final String[] nav={"Главная","Устройства","Разработка","Технологии","Холдинг","Рынок"};
    final String[] editorTabs={"Дизайн","Экран","Камеры","Процессор","Память","Батарея","Корпус","ПО"};
    GameView(MainActivity x){super(x);a=x;setBackgroundColor(BG);}
    void box(Canvas c,float x,float y,float w,float h,int col){p.setColor(col);c.drawRoundRect(x,y,x+w,y+h,10,10,p);}
    void stroke(Canvas c,float x,float y,float w,float h,int col){p.setColor(col);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);c.drawRoundRect(x,y,x+w,y+h,10,10,p);p.setStyle(Paint.Style.FILL);}
    void t(Canvas c,String s,float x,float y,float z,int col){p.setColor(col);p.setTextSize(z);p.setTypeface(Typeface.create("sans",Typeface.NORMAL));c.drawText(s,x,y,p);}
    void b(Canvas c,String s,float x,float y,float z,int col){p.setColor(col);p.setTextSize(z);p.setTypeface(Typeface.create("sans",Typeface.BOLD));c.drawText(s,x,y,p);}
    String money(double x){return String.format(Locale.US,"$%,.0f",x);}
    @Override protected void onDraw(Canvas c){super.onDraw(c);sc=getWidth()/1180f;c.save();c.scale(sc,sc);float H=getHeight()/sc;
        box(c,0,0,1180,H,BG);box(c,0,0,220,H,NAV);header(c,H);sidebar(c,H);
        if(screen==0)home(c); else if(screen==1)devices(c); else if(screen==2)editor(c); else if(screen==3)tech(c); else if(screen==4)holding(c); else market(c);c.restore();
    }
    void header(Canvas c,float H){box(c,220,0,960,68,Color.rgb(8,20,32));b(c,"$"+String.format(Locale.US,"%,.0f",a.company.cash),705,29,17,GREEN);t(c,"◆ "+a.company.research+" RP",900,29,14,CYAN);t(c,a.company.day+"."+a.company.month+"."+a.company.year,1050,29,13,MUTED);t(c,"▲ +2.1%",1040,51,10,GREEN);}
    void sidebar(Canvas c,float H){b(c,"◆",25,39,28,CYAN);b(c,a.company.name,64,32,19,TEXT);t(c,"TECH EMPIRE",64,51,9,MUTED);String[] ic={"⌂","▣","⚙","✦","◈","◉"};for(int i=0;i<nav.length;i++){float y=88+i*56;if(i==screen)box(c,10,y-29,198,46,Color.rgb(12,72,92));t(c,ic[i],28,y,17,i==screen?CYAN:MUTED);b(c,nav[i],58,y,14,i==screen?TEXT:MUTED);}t(c,"v0.4 • NEW UI",27,H-24,10,MUTED);}
    void title(Canvas c,String s,String sub){b(c,s,250,108,26,TEXT);t(c,sub,250,134,13,MUTED);}
    void metric(Canvas c,float x,float y,float w,String label,String val,String delta){box(c,x,y,w,105,PANEL);t(c,label,x+16,y+27,12,MUTED);b(c,val,x+16,y+63,22,TEXT);t(c,delta,x+16,y+87,12,GREEN);}
    void home(Canvas c){title(c,"Обзор компании","Разработка технологий и управление собственной экосистемой");metric(c,250,165,210,"Оценка компании",money(a.company.valuation),"▲ 12.8%");metric(c,475,165,210,"Фанаты",String.format(Locale.US,"%,.0f",a.company.fans),"▲ 8.4%");metric(c,700,165,210,"R&D",a.company.research+" RP","▲ "+(2+a.company.officeLevel)+" / день");metric(c,925,165,230,"Рейтинг бренда","4.8 / 5","▲ 0.2");
        box(c,250,290,570,335,PANEL);b(c,"Последние продукты",270,323,18,TEXT);int y=355;for(int i=0;i<Math.min(4,a.company.products.size());i++){Model.Product q=a.company.products.get(i);box(c,270,y,530,58,PANEL2);deviceMini(c,q,282,y+8,42);b(c,q.name,342,y+23,15,TEXT);t(c,q.type.title,342,y+43,11,MUTED);t(c,String.format(Locale.US,"★ %.1f",q.rating),635,y+27,14,GOLD);t(c,stageName(q.stage),694,y+45,11,q.stage==Model.Stage.RELEASED?GREEN:MUTED);y+=68;}
        box(c,840,290,315,335,PANEL);b(c,"Быстрые действия",862,323,18,TEXT);action(c,862,350,270,52,"Создать устройство",0);action(c,862,415,270,52,"Технологии",1);action(c,862,480,270,52,"Холдинг",2);action(c,862,545,270,52,"Рынок",3);
    }
    void action(Canvas c,float x,float y,float w,float h,String s,int id){box(c,x,y,w,h,Color.rgb(12,57,73));b(c,s,x+17,y+33,14,TEXT);t(c,"›",x+w-28,y+33,22,CYAN);}
    String stageName(Model.Stage s){if(s==Model.Stage.DRAFT)return"Черновик";if(s==Model.Stage.DEVELOPMENT)return"Разработка";if(s==Model.Stage.PRODUCTION)return"Производство";return"В продаже";}
    void devices(Canvas c){title(c,"Устройства","Создавай линейки и открывай полноценный визуальный редактор");action(c,925,90,230,45,"+ Новое устройство",10);int y=165;for(int i=0;i<a.company.products.size();i++){Model.Product q=a.company.products.get(i);box(c,250,y,905,112,PANEL);deviceMini(c,q,270,y+15,70);b(c,q.name,365,y+28,18,TEXT);t(c,q.type.title+" • Lv."+q.level,365,y+51,12,MUTED);t(c,"★ "+String.format(Locale.US,"%.1f",q.rating)+" / 10",365,y+78,15,GOLD);t(c,"Качество "+q.quality,560,y+28,12,MUTED);bar(c,560,y+43,250,q.quality/100f);t(c,money(q.price),850,y+28,17,GREEN);t(c,stageName(q.stage),850,y+53,12,q.stage==Model.Stage.RELEASED?GREEN:MUTED);t(c,"Продано: "+q.units,850,y+78,12,MUTED);y+=130;if(y>getHeight()/sc-120)break;}}
    void deviceMini(Canvas c,Model.Product q,float x,float y,float h){drawDevice(c,q,x,y,h);}
    void drawDevice(Canvas c,Model.Product q,float x,float y,float h){float w=h*.56f;int[] cols={Color.rgb(55,112,236),Color.rgb(157,78,232),Color.rgb(32,185,177),Color.rgb(223,82,105),Color.rgb(235,170,64),Color.rgb(75,75,85)};int col=cols[Math.max(0,Math.min(cols.length-1,q.bodyColor))];
        if(q.type==Model.Type.SMARTPHONE||q.type==Model.Type.TABLET){box(c,x,y,w,h,Color.rgb(35,42,52));box(c,x+3,y+3,w-6,h-6,col);box(c,x+8,y+10,w-16,h-20,Color.rgb(8,19,33));if(q.notch)box(c,x+w*.35f,y+9,w*.3f,8,Color.rgb(5,8,12));for(int i=0;i<3;i++){p.setColor(Color.rgb(30,30,35));c.drawCircle(x+w*.78f,y+18+i*11,4,p);}}
        else if(q.type==Model.Type.LAPTOP){box(c,x,y+h*.18f,w,h*.48f,Color.rgb(34,42,51));box(c,x+7,y+h*.23f,w-14,h*.38f,col);box(c,x-w*.08f,y+h*.68f,w*1.16f,8,Color.rgb(110,120,130));}
        else if(q.type==Model.Type.WATCH){box(c,x+w*.18f,y,w*.64f,h,Color.rgb(38,43,50));box(c,x+w*.25f,y+h*.2f,w*.5f,h*.6f,col);}
        else if(q.type==Model.Type.HEADPHONES){p.setColor(Color.rgb(40,45,52));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(9);c.drawArc(x,y,w,h*.8f,180,180,false,p);p.setStyle(Paint.Style.FILL);box(c,x-4,y+h*.42f,16,32,col);box(c,x+w-12,y+h*.42f,16,32,col);}
        else if(q.type==Model.Type.CONSOLE){box(c,x,y+h*.25f,w,h*.45f,Color.rgb(28,34,44));box(c,x+8,y+h*.31f,w-16,h*.25f,col);}
        else {box(c,x,y,w,h,Color.rgb(31,40,50));box(c,x+5,y+5,w-10,h-10,col);}
    }
    void editor(Canvas c){if(a.company.products.isEmpty()){title(c,"Редактор устройства","Создай продукт сначала");return;}Model.Product q=a.company.products.get(Math.min(selected,a.company.products.size()-1));title(c,"Редактор устройства","Настрой дизайн, компоненты, технологии и выпуск");
        box(c,250,155,180,440,PANEL);b(c,"ЭТАПЫ",270,185,12,MUTED);step(c,270,208,"1","Разработка",q.stage==Model.Stage.DEVELOPMENT||q.stage==Model.Stage.DRAFT);step(c,270,260,"2","Производство",q.stage==Model.Stage.PRODUCTION);step(c,270,312,"3","Релиз",q.stage==Model.Stage.RELEASED);b(c,"Dev Points",270,390,12,MUTED);b(c,String.valueOf(q.devPoints),270,422,28,CYAN);t(c,"получаются при\nразработке",270,450,11,MUTED);action(c,270,480,140,40,"+ Разработать",50);action(c,270,528,140,40,"Производство",51);action(c,270,576,140,40,"Релиз",52);
        box(c,445,155,320,440,PANEL);b(c,"ВИЗУАЛЬНЫЙ ПРЕДПРОСМОТР",465,184,12,MUTED);drawDevice(c,q,535,215,225);b(c,q.name,500,465,19,TEXT);t(c,q.type.title,545,488,12,MUTED);colorDots(c,q,492,515);t(c,"Форма",492,550,11,MUTED);choice(c,545,528,90,"Прямая",!q.curved);choice(c,642,528,90,"Скругл.",q.curved);
        box(c,780,155,375,440,PANEL);b(c,"НАСТРОЙКИ",800,184,12,MUTED);for(int i=0;i<editorTabs.length;i++){float xx=800+(i%2)*170,yy=205+(i/2)*48;choice(c,xx,yy,155,editorTabs[i],i==editorTab);}b(c,"ХАРАКТЕРИСТИКИ",800,350,12,MUTED);drawStats(c,q);b(c,"ОЦЕНКА",800,480,12,MUTED);b(c,String.format(Locale.US,"★ %.1f / 10",q.rating),800,510,25,GOLD);t(c,"Цена "+money(q.price)+" • себестоимость "+money(q.cost),800,535,11,MUTED);
        editorPanel(c,q);
    }
    void step(Canvas c,float x,float y,String n,String s,boolean on){p.setColor(on?CYAN:LINE);c.drawCircle(x+12,y+12,12,p);b(c,n,x+8,y+17,11,BG);b(c,s,x+34,y+17,13,on?TEXT:MUTED);}
    void choice(Canvas c,float x,float y,float w,String s,boolean on){box(c,x,y,w,36,on?Color.rgb(10,87,107):PANEL2);stroke(c,x,y,w,36,on?CYAN:LINE);t(c,s,x+10,y+23,11,on?TEXT:MUTED);}
    void colorDots(Canvas c,Model.Product q,float x,float y){for(int i=0;i<6;i++){p.setColor(new int[]{Color.rgb(60,115,235),Color.rgb(157,78,232),Color.rgb(32,185,177),Color.rgb(223,82,105),Color.rgb(235,170,64),Color.rgb(75,75,85)}[i]);c.drawCircle(x+i*25,y,8,p);if(i==q.bodyColor){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(TEXT);c.drawCircle(x+i*25,y,11,p);p.setStyle(Paint.Style.FILL);}}}
    void drawStats(Canvas c,Model.Product q){String[] n={"Дизайн","Экран","Камера","Производительность","Батарея","Надёжность","ПО","Цена/качество"};int[] v={q.design,q.display,q.camera,q.performance,q.battery,q.durability,q.software,q.value};for(int i=0;i<8;i++){float yy=438+i*0;int col=i%2,row=i/2;float x=800+col*175,y=438+row*35;t(c,n[i],x,y,10,MUTED);t(c,String.valueOf(v[i]),x+145,y,10,TEXT);bar(c,x,y+7,155,v[i]/100f);}}
    void editorPanel(Canvas c,Model.Product q){box(c,250,610,905,95,PANEL);b(c,editorTabs[editorTab].toUpperCase(Locale.US),270,636,12,MUTED);if(editorTab==0){t(c,"Цвет, форма корпуса, вырез и визуальный стиль",270,662,13,TEXT);t(c,"Выбор цвета меняет корпус устройства и дизайн.",270,687,11,MUTED);}
        else {String[][] opts={{"AMOLED","OLED","LTPO","120 Hz"},{"OIS","AI Camera","Telephoto","Macro"},{"8-core","Custom SoC","Liquid cooling","Ray tracing"},{"128 GB","256 GB","512 GB","1 TB"},{"4500 mAh","5000 mAh","Fast Charge","Wireless"},{"Aluminium","Titanium","Glass","Reinforced"},{"NovaOS","AI assistant","Privacy","Gaming mode"}};int idx=Math.max(0,editorTab-1);String[] os=opts[Math.min(idx,opts.length-1)];for(int i=0;i<4;i++)choice(c,270+i*215,650,195,os[i],i==0);}
    }
    void tech(Canvas c){title(c,"Технологии","Исследуй новые возможности и применяй их к продуктам");int y=165;Model.Tech[] ts=Model.Tech.values();for(int i=0;i<ts.length;i++){int col=i%3,row=i/3;float x=250+col*300,yy=165+row*94;box(c,x,yy,280,76,PANEL);b(c,techName(ts[i]),x+14,yy+27,13,TEXT);boolean open=a.company.unlocked.contains(ts[i]);t(c,open?"ОТКРЫТО":""+(a.company.techCost(ts[i]))+" RP",x+14,yy+51,11,open?GREEN:MUTED);if(!open)action(c,x+160,yy+13,105,45,"Открыть",30+i);}}
    String techName(Model.Tech t){return t.name().replace('_',' ');}
    void holding(Canvas c){title(c,"Холдинг","Дочерние компании, направления и переводы средств");box(c,250,165,430,455,PANEL);b(c,a.company.name,272,198,20,TEXT);t(c,money(a.company.cash),272,230,18,GREEN);t(c,"Дочерних компаний: "+a.company.subsidiaries.size(),272,258,13,MUTED);action(c,272,290,380,48,"Создать дочернюю компанию",40);int y=360;for(Model.Subsidiary s:a.company.subsidiaries){box(c,272,y,380,62,PANEL2);b(c,s.name,290,y+25,14,TEXT);t(c,money(s.cash),500,y+25,13,GREEN);y+=73;}box(c,705,165,450,455,PANEL);b(c,"Финансы",728,198,19,TEXT);t(c,"Переводы между компаниями",728,226,12,MUTED);action(c,728,260,390,48,"Холдинг → дочерняя",41);action(c,728,320,390,48,"Дочерняя → холдинг",42);}
    void market(Canvas c){title(c,"Рынок","Рейтинг продукта напрямую определяет спрос и продажи");box(c,250,165,905,160,PANEL);b(c,"Формула спроса",275,198,18,TEXT);t(c,"Рейтинг",275,232,12,MUTED);bar(c,345,225,330,.88f);t(c,"88%",685,232,12,GREEN);t(c,"Высокий рейтинг увеличивает базовый спрос, рост фанатов и повторные покупки.",275,270,13,MUTED);t(c,"Цена/качество корректирует конверсию.",275,294,13,MUTED);b(c,"Лучшие продукты",250,365,20,TEXT);ArrayList<Model.Product> ps=new ArrayList<>(a.company.products);ps.sort((x,z)->Double.compare(z.rating,x.rating));int y=400;for(Model.Product q:ps){box(c,250,y,905,60,PANEL);b(c,q.name,270,y+25,15,TEXT);t(c,q.type.title,270,y+45,11,MUTED);t(c,"★ "+String.format(Locale.US,"%.1f",q.rating),650,y+28,15,GOLD);t(c,"Продажи: "+q.units,780,y+28,13,TEXT);y+=70;}}
    @Override public boolean onTouchEvent(MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;float x=e.getX()/sc,y=e.getY()/sc;
        if(x<220&&y>60){int n=(int)((y-60)/56);if(n>=0&&n<nav.length){screen=n;invalidate();}return true;}
        if(screen==0&&y>335&&y<415&&x>840){a.createProduct();return true;}
        if(screen==1&&y>80&&y<150&&x>900){a.createProduct();return true;}
        if(screen==1&&y>155){selected=Math.max(0,Math.min(a.company.products.size()-1,(int)((y-165)/130)));screen=2;invalidate();return true;}
        if(screen==2){Model.Product q=a.company.products.get(Math.min(selected,a.company.products.size()-1));
            if(y>195&&y<400&&x>780){int col=x>965?1:0;int row=(int)((y-195)/48);editorTab=Math.max(0,Math.min(7,row*2+col));invalidate();return true;}
            if(y>500&&y<550&&x>270&&x<440){if(x<320)q.bodyColor=Math.max(0,q.bodyColor-1);else q.bodyColor=Math.min(5,q.bodyColor+1);q.recalc();invalidate();return true;}
            if(y>520&&y<575&&x>545&&x<745){q.curved=x>640;q.design=Math.min(100,q.design+2);q.recalc();invalidate();return true;}
            if(y>470&&y<525&&x<430){a.developSelected();invalidate();return true;}
            if(y>520&&y<570&&x<430){a.produceSelected();invalidate();return true;}
            if(y>570&&y<620&&x<430){a.releaseSelected();invalidate();return true;}
            if(y>630&&y<710){if(editorTab==0){q.notch=!q.notch;q.design=Math.min(100,q.design+1);}else a.applyEditorOption(editorTab);invalidate();return true;}
        }
        if(screen==3&&x>850){int idx=(int)((y-165)/94)*3+((int)(x-250)/300);if(idx>=0&&idx<Model.Tech.values().length)a.researchTech(Model.Tech.values()[idx]);invalidate();return true;}
        if(screen==4&&y>270&&y<340){a.createSubsidiary();return true;}
        return true;}
}
